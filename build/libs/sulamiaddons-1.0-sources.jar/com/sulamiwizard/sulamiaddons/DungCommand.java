package com.sulamiwizard.sulamiaddons;

import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;

public class DungCommand extends CommandBase {
    @Override
    public String func_71517_b() {
        return "dung";
    }

    @Override
    public String func_71518_a(ICommandSender sender) {
        return "";
    }

    @Override
    public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
        Minecraft.func_71410_x().field_71439_g.func_71165_d("/warp dungeon_hub");
    }

    @Override
    public int func_82362_a() {
        return 0;
    }
}