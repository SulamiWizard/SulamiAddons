
package com.sulamiwizard.sulamiaddons;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

import java.util.Iterator;

public class NameCommand extends CommandBase {
    @Override
    public String func_71517_b() {
        return "name";
    }

    @Override
    public String func_71518_a(ICommandSender sender) {
        return "";
    }

    @Override
    public void func_71515_b(final ICommandSender sender, final String[] args) throws CommandException {
        if(args.length > 0) {
            new Thread() {
                @Override
                public void run() {

                    JsonObject response = Utils.getJsonResponse("https://api.mojang.com/users/profiles/minecraft/" + args[0]).getAsJsonObject();
                    if(response.has("error")){
                        sender.func_145747_a(new ChatComponentText(EnumChatFormatting.GREEN + "error: " + response.get("errorMessage").getAsString()));
                        return;
                    }
                    if(!response.has("id")){
                        sender.func_145747_a(new ChatComponentText(EnumChatFormatting.GREEN + "error: Player does not exist."));
                    }
                    JsonArray response2 = Utils.getJsonResponse("https://api.mojang.com/user/profiles/" + response.get("id").getAsString() + "/names").getAsJsonArray();
                    for (Iterator<JsonElement> it = response2.iterator(); it.hasNext(); ) {
                        JsonObject jsonObject = it.next().getAsJsonObject();
                        if(jsonObject.has("name")){
                            sender.func_145747_a(new ChatComponentText(EnumChatFormatting.GREEN + jsonObject.get("name").getAsString()));
                        }
                    }
                }
            }.start();
        }

    }

    @Override
    public int func_82362_a() {
        return 0;
    }
}