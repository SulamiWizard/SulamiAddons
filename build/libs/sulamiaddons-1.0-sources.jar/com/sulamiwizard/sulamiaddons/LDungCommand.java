package com.sulamiwizard.sulamiaddons;

import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;

public class LDungCommand extends CommandBase {
    Thread commandThread = new Thread();

    @Override
    public String func_71517_b() {
        return "dung";
    }

    @Override
    public String func_71518_a(ICommandSender sender) {
        return "";
    }

    @Override
    public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
        new Thread(() -> {
            try {
                Minecraft.getMinecraft().thePlayer.sendChatMessage("/lobby");
                Thread.sleep(600);
                Minecraft.getMinecraft().thePlayer.sendChatMessage("/play skyblock");
                Thread.sleep(600);
                Minecraft.getMinecraft().thePlayer.sendChatMessage("/warp dungeon_hub");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }

    @Override
    public int func_82362_a() {
        return 0;
    }
}