package com.sulamiwizard.sulamiaddons;

import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;

public class DoubleHubWarpCommand extends CommandBase {
    Thread commandThread = new Thread();

    @Override
    public String func_71517_b() {
        return "hh";
    }

    @Override
    public String func_71518_a(ICommandSender sender) {
        return "";
    }

    @Override
    public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
            new Thread() {
                public void run() {
                    try {
                        Minecraft.func_71410_x().field_71439_g.func_71165_d("/warp hub");
                        Thread.sleep(600);
                        Minecraft.func_71410_x().field_71439_g.func_71165_d("/warp hub");
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                }
            }
        }.start();
    }

    @Override
    public int func_82362_a() {
        return 0;
    }
}