package com.sulamiwizard.sulamiaddons;


import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = SulamiAddons.MODID, version = SulamiAddons.VERSION, name = SulamiAddons.NAME)
public class SulamiAddons {
    public static final String MODID = "sulamiaddons";
    public static final String VERSION = "1.0";
    public static final String NAME = "SulamiAddons";

    @EventHandler
    public void preInit(FMLPreInitializationEvent event){

    }

    @EventHandler
    public void init(FMLInitializationEvent event){
        ClientCommandHandler.instance.func_71560_a(new LDungCommand());
        ClientCommandHandler.instance.func_71560_a(new DungCommand());
        ClientCommandHandler.instance.func_71560_a(new NameCommand());
        ClientCommandHandler.instance.func_71560_a(new GuildOnlineCommand());
        ClientCommandHandler.instance.func_71560_a(new DoubleHubWarpCommand());
        ClientCommandHandler.instance.func_71560_a(new F1Command());
        ClientCommandHandler.instance.func_71560_a(new F2Command());
        ClientCommandHandler.instance.func_71560_a(new F3Command());
        ClientCommandHandler.instance.func_71560_a(new F4Command());
        ClientCommandHandler.instance.func_71560_a(new F5Command());
        ClientCommandHandler.instance.func_71560_a(new F6Command());
        ClientCommandHandler.instance.func_71560_a(new F7Command());
    }

    @EventHandler
    public void postInit(FMLPostInitializationEvent event){

    }
}
